package com.tac.guns.client.animation.interpolator;

import com.tac.guns.client.animation.ObjectAnimationChannel;

public class Spline implements Interpolator {
    @Override
    public void compile(ObjectAnimationChannel channel) {
        // TODO
    }

    @Override
    public void interpolate(int indexFrom, int indexTo, float alpha, float[] result) {
        // TODO
    }
}
